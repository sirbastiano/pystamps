"""Packaged parity contract manifests."""
